<div id="modalerror" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Ocurrió un Error!!!!</h4>
            </div>
            <div class="modal-body">
                <center>
                    <i class="fa fa-warning fa-5x" style="color: red"></i>
                    <h3 style="font-weight: 900">Error en la petición con la Base de datos.</h3>
                    <h3>¡Recargue la página!</h3><br>
                    <code><h4 id="datoerror"></h4></code>
                </center>
                <br>
            </div>
        </div>

    </div>
</div>