<div id="loading">
    <div class="svg-icon-loader">
        <img src="<?= base_url('static/admin/') ?>assets/images/svg-loaders/bars.svg" width="40" alt="">
    </div>
</div>