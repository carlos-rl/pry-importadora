<!-- Main vendor Scripts-->

<!-- JS Demo -->
<script type="text/javascript" src="<?= base_url() ?>static/admin/assets/admin-all-demo.js"></script>